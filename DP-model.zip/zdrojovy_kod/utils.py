import datetime

def prt(str):
    print("[%s] - %s" % (datetime.datetime.now(), str))